import { Document } from 'mongoose';

export interface I<%= classify(name) %> {
}

export type I<%= classify(name) %>Doc = Document & I<%= classify(name) %>;