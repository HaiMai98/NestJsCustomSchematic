export class Create<%= singular(classify(name)) %>Dto {}
